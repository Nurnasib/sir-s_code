<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-body rounded-0">
                        <img src="<?php echo e(asset($subject->image)); ?>" alt="" class="w-100"/>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-body rounded-0">
                        <h1><?php echo e($subject->title); ?></h1>
                        <p>Course Fee : <?php echo e($subject->fee); ?></p>
                        <a href="<?php echo e(route('enroll-now', ['id' => $subject->id])); ?>" class="btn btn-success w-25 mx-auto <?php echo e($check == true ? 'disabled btn-danger' : ''); ?> "> Enroll Now </a>
                        <hr/>
                        <h2>Trainer Name: <?php echo e($subject->teacher->name); ?></h2>
                        <img src="<?php echo e(asset($subject->teacher->image)); ?>" alt="" height="100" width="100"/>
                        <hr/>
                        <div><?php echo $subject->short_description; ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card card-body rounded-0">
                        <h1>Course Module Detail</h1>
                        <hr/>
                        <div><?php echo $subject->long_description; ?></div>
                        <hr/>
                        <a href="" class="btn btn-outline-success w-25 mx-auto"> Enroll Now </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/website/course/detail.blade.php ENDPATH**/ ?>