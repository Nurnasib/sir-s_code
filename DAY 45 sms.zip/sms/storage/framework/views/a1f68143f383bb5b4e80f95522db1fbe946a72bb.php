<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Subject Title</th>
                        <td><?php echo e($subject->title); ?></td>
                    </tr>
                    <tr>
                        <th>Subject Code</th>
                        <td><?php echo e($subject->code); ?></td>
                    </tr>
                    <tr>
                        <th>Subject Fee</th>
                        <td><?php echo e($subject->fee); ?></td>
                    </tr>
                    <tr>
                        <th>Short Description</th>
                        <td><?php echo $subject->short_description; ?></td>
                    </tr>
                    <tr>
                        <th>Long Description</th>
                        <td><?php echo $subject->long_description; ?></td>
                    </tr>
                    <tr>
                        <th>Trainer Name</th>
                        <td><?php echo e($subject->teacher->name); ?></td>
                    </tr>
                    <tr>
                        <th>Feature Image</th>
                        <td>
                            <img src="<?php echo e(asset($subject->image)); ?>" alt=""/>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/course/detail.blade.php ENDPATH**/ ?>