Simple Student Management System

Part/panel of Application:

Website
Admin Panel
Student Panel
Teacher Panel 

Feature list of each part/panel:
Website
	Home Page
		Menu Section
		Course List with Teacher info	
		Subscriber Section
		Notice Section
		A Footer Section
	Couser Detail
		Individual course detail info 
	Login Page
		Login Form
	Registration Page
		Registration Form
		Confirmation email
===================================
Admin Panel:
	Login & logout system
	Admin create new admin user
	Create create and manage teacher
	Admin manage teacher course
	Admin manage student registration
	Confirmation email
=========================
Teacher Panel
	Login / logout system
	Teacher create, update course
	Teacher can see his or her published course
	Teacher can see enrolled student
=========================
Student Panel
	Login / logout system
	Student can see total apply couse
	Student can see total approved couse

	
		
	

	
	
